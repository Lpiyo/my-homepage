# Create Academy 1.21.1

Minecraft 1.21.1 / NeoForge 21.1.233 / Create 6.0.10 기반의 초보자용 모드팩입니다.

## 설치

1. CurseForge에서 Minecraft 1.21.1, NeoForge 21.1.233 사용자 프로필을 새로 만드세요.
2. 게임을 한 번 실행한 뒤 완전히 종료하세요.
3. 이 폴더의 `mods`, `config`, `kubejs`, `resourcepacks`, `shaderpacks`를 새 프로필 폴더에 복사하세요.
4. Java 21과 메모리 6~8GB를 사용하세요.
5. 새 월드를 만드는 것을 권장합니다.

기존 `create mod` 1.20.1 프로필은 삭제하거나 덮어쓰지 마세요.

## 퀘스트 구성

- 1장: 나무, 작업대, 철, 창고, 배낭
- 2장: 안산암 합금, 렌치, 고글, 축, 톱니, 물레방아와 기본 가공기
- 3장: 벨트, 깔때기, 터널, 슈트, 팬, 액체 물류
- 4장: 디플로이어, 순차 조립, 기계식 조합기, 기계 팔과 재고 제어
- 5장: 증기, 전력 변환, 식량, 낚시, 철도와 건축
- 6장: AE2 재료부터 자동 제작 CPU까지
- 7장: 벌, Hostile Neural Networks와 광맥 채굴
- 8장: MEGA Cells와 Advanced AE 대형 공장

총 65개 퀘스트이며 모든 퀘스트는 바로 앞 단계를 완료해야 열립니다.

## 초보자 조작

- JEI 제작법: 아이템 위에서 `R`
- JEI 사용처: 아이템 위에서 `U`
- Create Ponder 설명: Create 아이템 위에서 `W`를 길게 누르기
- 셰이더 켜기/끄기: 기본적으로 꺼져 있으며 Iris 키 설정에서 변경

## 성능 권장값

- 렌더 거리 12
- 시뮬레이션 거리 8
- 입자 감소
- 셰이더는 탐험이나 촬영 때만 켜고 대형 공장에서는 끄기

## 음악

`Server_Music_Pack/assets/servermusic/sounds/music`에 `song01.ogg`부터 `song10.ogg`를 넣고 리소스팩을 다시 압축하세요.

```text
/servermusic play song01
/servermusic stop
```

// /servermusic play song01 ~ song10
// /servermusic stop
ServerEvents.commandRegistry(event => {
  const { commands: Commands } = event
  const musicTracks = {}
  for (var musicIndex = 1; musicIndex <= 10; musicIndex++) {
    var musicTrackId = 'song' + String(musicIndex).padStart(2, '0')
    musicTracks[musicTrackId] = 'servermusic:' + musicTrackId
  }

  function playServerTrack(source, selectedTrack) {
    source.server.runCommandSilent('stopsound @a music')
    source.server.runCommandSilent('stopsound @a record')
    source.server.runCommandSilent(`playsound ${musicTracks[selectedTrack]} record @a ~ ~ ~ 1 1 1`)
    source.server.runCommandSilent(`tellraw @a {"text":"♫ 서버 음악: ${selectedTrack}","color":"gold"}`)
    return 1
  }

  let musicPlayCommand = Commands.literal('play')
  Object.keys(musicTracks).forEach(musicTrackName => {
    musicPlayCommand = musicPlayCommand.then(
      Commands.literal(musicTrackName).executes(context => playServerTrack(context.source, musicTrackName))
    )
  })

  event.register(
    Commands.literal('servermusic')
      .requires(source => source.hasPermission(2))
      .then(musicPlayCommand)
      .then(
        Commands.literal('stop').executes(context => {
          context.source.server.runCommandSilent('stopsound @a music')
          context.source.server.runCommandSilent('stopsound @a record')
          return 1
        })
      )
  )
})

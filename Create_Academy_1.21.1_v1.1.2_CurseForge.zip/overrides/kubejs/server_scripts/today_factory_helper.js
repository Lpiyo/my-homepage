// Create Academy: time-boxed quest planner and factory helper
// Commands:
// /오늘할일, /오늘할일 30분, /오늘할일 1시간, /오늘할일 2시간
// /공장도우미, /공장도우미 철판, 안산암, 황동, 조약돌, 나무, 광석, 음식, ae2

const TeamData = Java.loadClass('dev.ftb.mods.ftbquests.quest.TeamData')
const ServerQuestFile = Java.loadClass('dev.ftb.mods.ftbquests.quest.ServerQuestFile')
const JavaLong = Java.loadClass('java.lang.Long')
const IntegerArgumentType = Java.loadClass('com.mojang.brigadier.arguments.IntegerArgumentType')

const QUEST_IDS = [
  '2885DD6A4BCE351B','5F512FF1A9EB9C1B','737D6A8CB29DA46C','58915BFF034FFF3D','241F45BC409B1712','6E17C732679FE1FA','2ED9F3BD82277E8A',
  '52893D27F985D9B0','058C80CA96EA467D','4D7CE39F6444D2AF','2D0B8A97AF6265C7','59C92143E7E4F47D','5EBE98180466B0AC','2AC80A01BA17B497','699E17B78F781F61','1118C100160D0460',
  '08979DC95FA9D083','70369C3921895E1A','523AAAA77765D8AE','1DE945660DD3DC31','79AE9A9312489166','6B5633EC6DD4B526','3035ED41E454332A','7C36C90BBBE0C4DF',
  '11E52A5863BCE27B','28DC8CE16E9B68DD','71BAF07CC1A01A20','549723980A481E2B','24CCBD43C802F2B7','217819EC9402630E','77EBDB066554E58A','166887E53E73109E',
  '7AD96E8F20AF0A40','08BAA5C7EEBF2B4E','24F8B3FBDF0E12BE','45AADB14490EB2F1','54A50E696F448C0B','59D3119EA785F829','7D47D6A9E3BB248D',
  '69EA3B77ACA804E4','0FAF3DA033264818','5D3C5DA920834398','3640894B687CC85A','37396783CC4AB51E','0DD9D8EC151848C0','28D27B3B2BF37729','0BA651D3F99E1034','2FDD72442CE695E8','5EE8766223773301',
  '63B7576AFE2E70F9','1ECE3705929B30C5','29E5EDD1CE2E3CF3','6D04FA34E66472BE','4A2251D691DDDF89','4AA446C685501941','50EF7B49611DE5B7','398023713C5382E1',
  '124723F633FBA688','60E416A6FE732F35','7B47A736368CD917','718BF8DBCDFDA522','180FAD9F135C1464','59AB4EFBF09387D8','5E9FD39C403A981C','531B5C1CD2A2861C'
]

const CHAPTER_ENDS = [6,15,23,31,38,48,56,64]

function estimateMinutes(index) {
  if (index <= 2) return 10
  if (index <= 6) return 18
  if (index <= 15) return 22
  if (index <= 23) return 28
  if (index <= 31) return 35
  if (index <= 38) return 40
  if (index <= 48) return 45
  if (index <= 56) return 55
  return 65
}

function chapterNumber(index) {
  for (let i = 0; i < CHAPTER_ENDS.length; i++) if (index <= CHAPTER_ENDS[i]) return i + 1
  return 8
}

function questAt(index) {
  const id = JavaLong.parseUnsignedLong(QUEST_IDS[index], 16)
  return ServerQuestFile.INSTANCE.getQuest(id)
}

function playerFrom(source) {
  try { return source.getPlayerOrException() } catch (e) { return null }
}

function tell(player, text, color) {
  player.tell(Text.of(text).color(color || 'white'))
}

function showToday(source, budget) {
  const player = playerFrom(source)
  if (!player) return 0

  const data = TeamData.get(player)
  let first = -1
  for (var firstQuestIndex = 0; firstQuestIndex < QUEST_IDS.length; firstQuestIndex++) {
    var firstQuest = questAt(firstQuestIndex)
    if (firstQuest && !data.isCompleted(firstQuest)) {
      first = firstQuestIndex
      break
    }
  }

  tell(player, '━━━━━━━━ 오늘 할 일 ━━━━━━━━', 'gold')
  if (first < 0) {
    tell(player, '모든 Create Academy 퀘스트를 완료했습니다!', 'green')
    return 1
  }

  let used = 0
  let selected = []
  for (var planQuestIndex = first; planQuestIndex < QUEST_IDS.length; planQuestIndex++) {
    var planMinutes = estimateMinutes(planQuestIndex)
    if (selected.length > 0 && used + planMinutes > budget) break
    var planQuest = questAt(planQuestIndex)
    if (!planQuest) continue
    selected.push({
      index: planQuestIndex,
      quest: planQuest,
      minutes: planMinutes
    })
    used += planMinutes
  }

  tell(player, `가용 시간: ${budget}분 · 예상 계획: 약 ${used}분`, 'yellow')
  for (var selectedGoalIndex = 0; selectedGoalIndex < selected.length; selectedGoalIndex++) {
    var selectedGoal = selected[selectedGoalIndex]
    var selectedGoalTitle = selectedGoal.quest.getTitle().getString()
    var selectedGoalPrefix = selectedGoalIndex === 0 ? '▶ 핵심' : '  다음'
    tell(
      player,
      `${selectedGoalPrefix}: ${selectedGoalTitle} (약 ${selectedGoal.minutes}분)`,
      selectedGoalIndex === 0 ? 'aqua' : 'white'
    )
  }
  tell(player, `현재 위치: ${chapterNumber(first)}장 · 전체 ${first + 1}/${QUEST_IDS.length}`, 'gray')
  tell(player, '막히면 JEI에서 재료를 확인하고 /공장도우미 를 사용하세요.', 'green')
  return 1
}

const FACTORIES = {
  '철판': {
    title: '초보 철판 공장',
    materials: '물레방아 1, 축 6+, 기계식 프레스 1, 디포 1, 깔때기 2, 상자 2',
    steps: [
      '물레방아에 축을 연결하고 프레스 위까지 동력을 전달합니다.',
      '프레스 바로 아래에 디포를 놓습니다.',
      '입력 상자 → 깔때기 → 디포 순서로 연결합니다.',
      '반대쪽에 깔때기와 출력 상자를 놓습니다.',
      '철 주괴 1개로 시험하고 출력이 막히지 않는지 확인합니다.'
    ],
    check: '프레스가 움직이지 않으면 회전 방향, 응력 과부하, 디포 위치를 확인하세요.'
  },
  '안산암': {
    title: '안산암 합금 자동화',
    materials: '기계식 믹서 1, 분지 1, 가열원, 깔때기/벨트, 철 조각 또는 아연 조각, 안산암',
    steps: [
      '분지 위에 기계식 믹서를 설치하고 동력을 연결합니다.',
      'JEI에서 현재 팩의 안산암 합금 레시피와 가열 조건을 확인합니다.',
      '두 재료를 서로 다른 입력 상자에서 분지로 공급합니다.',
      '완성품은 분지 측면 깔때기로 출력합니다.',
      '재료 비율이 어긋나지 않도록 소량으로 먼저 시험합니다.'
    ],
    check: '믹서가 내려오지 않으면 속도 부족, 분지 위치, 가열 조건을 확인하세요.'
  },
  '황동': {
    title: '황동 생산 라인',
    materials: '블레이즈 버너 1, 분지 1, 믹서 1, 구리 주괴, 아연 주괴, 연료',
    steps: [
      '분지 아래에 블레이즈 버너를 놓고 연료를 공급합니다.',
      '분지 위 믹서에 충분한 회전 속도를 공급합니다.',
      '구리와 아연을 같은 비율로 투입합니다.',
      '황동 주괴를 깔때기로 출력 상자에 보냅니다.',
      '버너 연료가 끊길 때 라인이 멈추도록 표시등을 추가합니다.'
    ],
    check: '황동이 안 나오면 블레이즈 버너 가열 상태와 JEI 레시피를 확인하세요.'
  },
  '조약돌': {
    title: '조약돌 무한 생산기',
    materials: '드릴 1, 선형 섀시 또는 고정 블록, 물 1, 용암 1, 벨트/깔때기',
    steps: [
      '물과 용암이 맞닿아 한 칸에 조약돌이 생성되게 만듭니다.',
      '생성 칸을 향해 기계식 드릴을 배치합니다.',
      '드릴에 동력을 연결하고 드롭 위치에 벨트를 둡니다.',
      '벨트 끝을 저장 서랍이나 금고에 연결합니다.',
      '저장량 감지기로 가득 차면 정지하도록 만듭니다.'
    ],
    check: '흑요석이 생기면 물과 용암의 흐르는 면 배치를 다시 확인하세요.'
  },
  '나무': {
    title: '자동 나무 농장',
    materials: '기계식 베어링 1, 방사형 섀시, 기계식 톱 2+, 이동식 저장소, 휴대용 저장 인터페이스',
    steps: [
      '평평한 흙 원형 농장을 만들고 묘목 간격을 확보합니다.',
      '베어링 위 섀시에 톱과 이동식 저장소를 부착합니다.',
      '톱이 나무 밑동 높이를 지나도록 맞춥니다.',
      '고정 저장 인터페이스와 상자를 연결합니다.',
      '한 바퀴 시험 후 충돌 구간과 묘목 재식재를 확인합니다.'
    ],
    check: '수확물이 안 나오면 두 저장 인터페이스가 마주 보는지 확인하세요.'
  },
  '광석': {
    title: '광석 분쇄·세척 라인',
    materials: '분쇄 휠 2, 벨트, 기계식 팬 1, 물, 황동/안산암 깔때기, 저장소',
    steps: [
      '분쇄 휠 두 개가 서로 반대 방향으로 안쪽을 향해 돌게 합니다.',
      '분쇄 결과를 벨트 위로 떨어뜨립니다.',
      '팬이 물을 통과해 벨트 위 재료를 세척하도록 배치합니다.',
      '산출물 종류별로 필터 깔때기를 달아 분류합니다.',
      '처리 속도보다 투입 속도가 빠르지 않게 조절합니다.'
    ],
    check: '아이템이 튕기면 분쇄 휠 방향과 팬 바람 방향을 확인하세요.'
  },
  '음식': {
    title: '자동 요리 공장',
    materials: '분지, 믹서, 가열원, 디포/벨트, Farmer’s Delight 조리 도구',
    steps: [
      '반복 생산할 음식 하나를 JEI에서 선택합니다.',
      '재료별 입력 상자를 분리하고 필터 깔때기를 설정합니다.',
      '혼합·가열 공정은 분지와 믹서로 구성합니다.',
      '칼질이 필요하면 도마 공정을 별도 라인으로 둡니다.',
      '완성 음식은 일반 재료 저장소와 분리합니다.'
    ],
    check: '용기 아이템이 필요한 레시피인지, 잔여 용기 출력이 막혔는지 확인하세요.'
  },
  'ae2': {
    title: 'AE2 프로세서 자동화',
    materials: '각인기 3~5, 패턴 공급기, 가져오기 버스, 전력, 실리콘/인쇄 회로',
    steps: [
      '실리콘·논리·계산·엔지니어링 회로 각인기를 분리합니다.',
      '각 각인기에 전용 프레스를 고정합니다.',
      '최종 조립 각인기에 인쇄 회로, 인쇄 실리콘, 레드스톤을 공급합니다.',
      '완성 프로세서를 가져오기 버스로 ME망에 회수합니다.',
      '처리 패턴을 하나씩 등록하고 중간 재료가 순환하는지 시험합니다.'
    ],
    check: '각인기 방향, 프레스 종류, 패턴 공급기의 출력 면을 확인하세요.'
  }
}

function compactGuide(title, materials, steps, check) {
  return { title: title, materials: materials, steps: steps, check: check }
}

// Content-bearing mods in the current pack. Libraries, UI-only mods and
// performance mods are intentionally omitted because they have no factory flow.
Object.assign(FACTORIES, {
  '증기발전기': compactGuide(
    'Create 증기 발전기',
    '유체 탱크 4+, 증기 기관, 블레이즈 버너, 물 공급 장치, 축',
    ['탱크를 2×2 이상으로 만듭니다.', '아래에서 가열하고 물을 계속 공급합니다.', '측면 증기 기관에서 축으로 동력을 꺼냅니다.', '보일러 화면의 물·열·크기 단계를 확인합니다.'],
    '물이 마르거나 버너 열이 부족하면 출력이 급격히 떨어집니다.'
  ),
  '디젤발전기': compactGuide(
    'Create Diesel Generators 발전소',
    '디젤 엔진, 연료 탱크, 유체 파이프, 펌프, 점화 장치',
    ['JEI에서 사용 가능한 연료를 고릅니다.', '연료 탱크에서 펌프로 엔진에 공급합니다.', '엔진 출력축을 주 동력망에 연결합니다.', '연료 부족 감지와 비상 정지 레드스톤을 추가합니다.'],
    '연료 종류, 파이프 방향, 엔진 점화 상태를 확인하세요.'
  ),
  '전기발전': compactGuide(
    'Create Crafts & Additions 전력망',
    '교류 발전기, 전기 모터, 커넥터, 전선, 축',
    ['회전축에 교류 발전기를 연결해 FE를 만듭니다.', '커넥터와 전선으로 저장소 또는 기계에 보냅니다.', '전기 모터로 FE를 다시 회전력으로 변환합니다.', '입출력 전력과 응력 용량을 함께 확인합니다.'],
    '커넥터 등급과 전선 연결 지점, 발전기 회전 속도를 확인하세요.'
  ),
  '신시대': compactGuide(
    'Create: New Age 전력과 토륨',
    '자석, 발전 코일, 전선, 전기 모터, 토륨 관련 장치',
    ['기본 발전 코일로 소규모 전력을 시험합니다.', '전선망을 생산 구역별로 분리합니다.', '토륨 장치는 JEI와 Ponder 순서대로 한 단계씩 제작합니다.', '발열 장치 주변에 차단 공간과 비상 정지를 둡니다.'],
    '회전 방향, 코일 배치, 전력 입출력 면을 확인하세요.'
  ),
  '철도': compactGuide(
    'Create Steam ’n’ Rails 철도망',
    '선로, 역, 열차 케이싱, 조종 장치, 신호기',
    ['두 역 사이에 먼저 단선 시험 노선을 놓습니다.', '역에서 열차를 조립하고 일정표를 넣습니다.', '교차 구간에 신호기와 신호 경계를 배치합니다.', '화물 인터페이스로 공장 저장소와 연결합니다.'],
    '열차 조립 모드, 선로 연결, 신호 구간 중복을 확인하세요.'
  ),
  '와이너리': compactGuide(
    'Create: Winery 생산 라인',
    '과일 농장, 압착/혼합 장치, 유체 탱크, 병입 장치',
    ['재배할 과일을 정하고 수확 라인을 만듭니다.', 'JEI의 압착·발효 순서대로 유체를 처리합니다.', '단계별 유체 탱크를 분리합니다.', '완성 음료만 마지막 병입 라인으로 보냅니다.'],
    '서로 다른 유체가 같은 탱크나 파이프에 섞이지 않게 하세요.'
  ),
  '카페': compactGuide(
    'Create Cafe 음료 공장',
    '작물 입력, 믹서와 분지, 가열원, 유체 탱크, 컵',
    ['음료 하나를 골라 JEI 공정을 확인합니다.', '고체 재료와 유체 재료 입력을 분리합니다.', '혼합·가열 후 전용 탱크에 저장합니다.', '컵 공급과 완성 음료 출력을 각각 관리합니다.'],
    '빈 컵이나 잔여 용기 출력이 막히지 않았는지 확인하세요.'
  ),
  '마법부여': compactGuide(
    'Create Enchantment Industry 경험치 공장',
    '인챈트 디스인챈터/프린터 계열 장치, 액체 경험치 탱크, 벨트',
    ['JEI에서 경험치 액체 생성 방법을 확인합니다.', '경험치 탱크를 별도 파이프망으로 분리합니다.', '책과 장비 입력을 필터링합니다.', '완성품과 부산물을 서로 다른 저장소로 보냅니다.'],
    '경험치 유체 종류와 장치별 입력 면을 확인하세요.'
  ),
  '광맥채굴': compactGuide(
    'Create Ore Excavation 광맥 공장',
    '샘플 드릴, 광맥 지도, 채굴기, 충분한 회전력, 저장소',
    ['샘플 드릴로 청크의 광맥을 조사합니다.', '원하는 광맥 위치에 채굴기를 설치합니다.', '대형 동력원과 출력 저장소를 연결합니다.', '저장량 감지기로 가득 차면 자동 정지시킵니다.'],
    '광맥 존재 여부, 드릴 요구 응력, 출력 공간을 확인하세요.'
  ),
  '광부클론': compactGuide(
    '광부 클론 운용',
    '석탄 8개(재충전), 광맥 근처의 안전한 설치 공간',
    ['광맥 중심에서 /광부클론 소환을 입력합니다.', '클론은 11×11×7 범위의 가까운 광석부터 2초마다 하나씩 캡니다.', '드롭된 광물은 직접 회수하거나 벨트·깔때기로 모읍니다.', '에너지가 떨어지면 /광부클론 충전, 이동하려면 회수 후 다시 소환합니다.'],
    '건축물은 캐지 않으며 바닐라·아연·토륨 광석만 대상으로 합니다.'
  ),
  '이동식패키지': compactGuide(
    'Create Mobile Packages 물류',
    '패키지 장치, 주소 설정, 벨트/슈트, 저장소',
    ['송신지와 수신지 주소를 정합니다.', '포장 입력과 일반 아이템 입력을 분리합니다.', '시험 패키지 하나를 보내 경로를 검증합니다.', '오배송 회수 상자를 별도로 둡니다.'],
    '주소 철자와 패키지 입출력 방향을 확인하세요.'
  ),
  '파워로더': compactGuide(
    'Create Power Loader 청크 물류',
    '파워 로더, 동력 연결, 열차 또는 고정 설비',
    ['항상 작동해야 하는 공장 경계를 정합니다.', '필요한 청크에만 로더를 배치합니다.', '동력과 활성 조건을 연결합니다.', '서버 부하를 줄이기 위해 불필요한 구역은 끕니다.'],
    '로더 범위와 중복 로딩 청크를 확인하세요.'
  ),
  '드래곤': compactGuide(
    'Create Dragons Plus 장치',
    '해당 장치 재료, Create 동력, Ponder 안내',
    ['JEI에서 원하는 Dragons Plus 장치를 찾습니다.', '장치를 든 채 W로 Ponder를 확인합니다.', '기본 Create 라인과 분리해 한 대만 시험합니다.', '안정화 후 기존 물류망에 연결합니다.'],
    '애드온 장치는 Create 버전에 민감하므로 Ponder 순서를 우선하세요.'
  ),
  'ae2저장': compactGuide(
    'Applied Energistics 2 저장망',
    '에너지 수용기, ME 드라이브, 저장 셀, 케이블, 터미널',
    ['전력을 공급하고 에너지 셀을 연결합니다.', '드라이브에 1K 또는 4K 셀부터 넣습니다.', '케이블 끝에 제작 터미널을 설치합니다.', '채널 사용량을 늘리기 전에 작은 망부터 시험합니다.'],
    '전력 부족, 채널 초과, 케이블 단절을 확인하세요.'
  ),
  'ae2자동조합': FACTORIES['ae2'],
  '고급ae': compactGuide(
    'Advanced AE 양자 자동화',
    '기본 AE2 자동 조합망, 양자 프로세서, 반응 챔버, 고급 패턴 공급기',
    ['기본 AE2 프로세서 자동화를 먼저 완성합니다.', '반응 챔버 재료 공급을 제한합니다.', '양자 프로세서를 수동으로 한 번 검증합니다.', '고급 패턴 공급기와 제작기를 단계적으로 연결합니다.'],
    '중간 재료 재귀 주문과 과도한 동시 제작을 확인하세요.'
  ),
  '메가셀': compactGuide(
    'MEGA Cells 대용량 저장',
    '축적 프로세서, 셀 부품, ME 드라이브, 충분한 전력',
    ['축적 프로세서 제작을 자동화합니다.', '1M 셀 하나부터 실제 사용량을 확인합니다.', '대량 생산물 전용 드라이브를 분리합니다.', '타입 수 제한과 총 용량을 함께 관리합니다.'],
    '셀 부품과 완성 셀을 혼동하지 않았는지 확인하세요.'
  ),
  '무선ae': compactGuide(
    'AE2 Wireless Terminals',
    '무선 터미널, 액세스 포인트, 에너지 셀, 보안 터미널',
    ['ME망에 무선 액세스 포인트를 연결합니다.', '보안 터미널에서 무선 장치를 등록합니다.', '터미널을 충전한 뒤 범위를 시험합니다.', '필요하면 액세스 포인트를 추가하되 채널을 확인합니다.'],
    '장치 등록, 충전량, 액세스 포인트 채널을 확인하세요.'
  ),
  '벌': compactGuide(
    'Productive Bees 자원 공장',
    '벌 케이지, 고급 벌통, 급식기, 확장 블록, 원심분리기',
    ['목표 자원을 생산하는 벌의 조건을 JEI에서 확인합니다.', '고급 벌통과 급식기를 설치합니다.', '생산물을 원심분리기로 보냅니다.', '출력을 AE2 또는 저장 서랍에 자동 보관합니다.'],
    '벌의 꽃/블록 조건, 낮밤 조건, 벌통 공간을 확인하세요.'
  ),
  '몬스터자원': compactGuide(
    'Hostile Neural Networks 자원 공장',
    '딥 러너, 데이터 모델, 시뮬레이션 챔버, 전리품 제작기, FE',
    ['빈 모델을 딥 러너에 넣고 대상 몬스터를 학습합니다.', '충분히 학습한 모델을 챔버에 넣습니다.', '예측을 전리품 제작기로 보냅니다.', '완성 드롭을 저장망에 자동 회수합니다.'],
    '모델 학습 등급, 챔버 전력, 예측 종류를 확인하세요.'
  ),
  '농사': compactGuide(
    'Farmer’s Delight 농장과 주방',
    '작물 농장, 도마, 칼, 조리 냄비, 저장소',
    ['자주 먹을 음식 하나를 선택합니다.', '필요 작물을 구역별로 재배합니다.', '도마 손질 재료와 냄비 재료를 분리합니다.', '완성 음식과 그릇 반환 경로를 만듭니다.'],
    '조리 용기와 잔여 그릇 때문에 출력이 막히지 않게 하세요.'
  ),
  '낚시': compactGuide(
    'Aquaculture 낚시 준비',
    '낚싯대, 미끼, 태클 박스, 보관함',
    ['현재 생물군계의 어종을 확인합니다.', '낚싯대와 미끼를 준비합니다.', '태클 박스에 부품을 정리합니다.', '생선은 음식·재료 용도로 분류 보관합니다.'],
    '미끼 장착과 낚싯대 내구도를 확인하세요.'
  ),
  '배낭': compactGuide(
    'Sophisticated Backpacks 이동식 창고',
    '배낭, 업그레이드 슬롯, 필터/자석/공급 업그레이드',
    ['기본 배낭을 만들고 전용 단축키를 확인합니다.', '용도별로 업그레이드를 하나씩 추가합니다.', '필터로 원치 않는 아이템 유입을 막습니다.', '중요 도구는 자동 공급 슬롯과 분리합니다.'],
    '업그레이드 필터와 배낭 내부 정렬 설정을 확인하세요.'
  ),
  '고급저장': compactGuide(
    'Sophisticated Storage 창고',
    '상자/배럴, 저장 업그레이드, 필터, 외부 물류 연결',
    ['재료 종류별 저장 구역을 정합니다.', '필요한 저장소만 단계적으로 업그레이드합니다.', '입출력 필터를 설정합니다.', 'Create 또는 AE2 연결 전 수동 입출력을 시험합니다.'],
    '필터 방향과 잠금 설정, 업그레이드 호환 여부를 확인하세요.'
  ),
  '간단저장': compactGuide(
    'Tom’s Simple Storage 통합 창고',
    '저장 터미널, 인벤토리 커넥터, 케이블, 기존 상자',
    ['중앙 커넥터를 기존 상자 근처에 둡니다.', '케이블로 모든 상자를 연결합니다.', '터미널에서 검색과 제작을 시험합니다.', 'Create 출력 상자는 같은 망에 연결합니다.'],
    '케이블 단절과 연결되지 않은 상자를 확인하세요.'
  ),
  '화로': compactGuide(
    'Iron Furnaces 제련실',
    '등급별 화로, 연료 또는 FE 업그레이드, 입출력 상자',
    ['현재 자원에 맞는 화로 등급을 선택합니다.', '입력·연료·출력 면을 구분합니다.', '깔때기나 파이프로 자동화합니다.', '속도 업그레이드 전 연료 공급을 충분히 만듭니다.'],
    '화로 측면 설정과 연료/전력 업그레이드 방식을 확인하세요.'
  ),
  '가구': compactGuide(
    '가구 모드 꾸미기',
    'Handcrafted, Macaw’s Furniture, Create Interiors 가구',
    ['방의 용도를 먼저 정합니다.', '큰 가구부터 배치하고 통로를 확보합니다.', 'Create Interiors와 Handcrafted 색상을 맞춥니다.', '조명은 너무 촘촘하지 않게 구역별로 둡니다.'],
    '의자 상호작용과 블록 방향은 렌치 또는 우클릭으로 확인하세요.'
  ),
  '건축': compactGuide(
    '건축 블록 도우미',
    'Chipped, FramedBlocks, Copycats+, Macaw’s 건축 블록',
    ['주 재료 2개와 포인트 재료 1개만 고릅니다.', 'FramedBlocks로 경사와 비정형 부분을 만듭니다.', 'Copycats로 Create 기계 주변 재질을 통일합니다.', 'Chipped 변형은 한 구역에 과하게 섞지 않습니다.'],
    'JEI에서 같은 재료의 변형 블록을 검색하세요.'
  ),
  '조명': compactGuide(
    '조명과 장식',
    'Macaw’s Lights, Supplementaries, Amendments 조명',
    ['작업 구역과 휴식 구역의 색온도를 나눕니다.', '기계 사이에는 벽·천장 조명을 사용합니다.', '레드스톤 제어가 필요한 조명은 별도 회로로 묶습니다.', '셰이더에서 과노출되지 않는지 밤에 확인합니다.'],
    '조명 블록의 레드스톤 반응과 셰이더 밝기를 확인하세요.'
  ),
  '상점': compactGuide(
    'Lightman’s Currency 상점',
    '화폐, 금고/지갑, 판매기 또는 거래 블록',
    ['서버에서 사용할 화폐 단위를 정합니다.', '판매 상품과 가격을 소량으로 시험합니다.', '판매기 재고를 별도 저장소에서 공급합니다.', '관리자용 회수·정산 공간을 둡니다.'],
    '소유권, 재고, 가격 단위를 다시 확인하세요.'
  ),
  '길찾기': compactGuide(
    'Waystones와 나침반 탐험',
    '웨이스톤, 귀환 아이템, 자연의 나침반, 탐험가의 나침반',
    ['본거지 웨이스톤을 먼저 등록합니다.', '자연의 나침반으로 원하는 생물군계를 찾습니다.', '탐험가의 나침반으로 구조물을 찾습니다.', '장거리 거점마다 이름 규칙을 통일합니다.'],
    '웨이스톤 비용 설정과 차원 이동 가능 여부를 확인하세요.'
  ),
  '낚시휴식': compactGuide(
    'Comforts 야외 거점',
    '침낭, 해먹, 조명, 배낭',
    ['탐험용 침낭을 준비합니다.', '거점 주변을 밝히고 상자를 둡니다.', '해먹과 침낭의 시간대 기능을 구분합니다.', '본거지 스폰 지점을 실수로 바꾸지 않게 합니다.'],
    '침낭이 스폰을 변경하는 설정인지 확인하세요.'
  ),
  '유물': compactGuide(
    'Artifacts 장비 활용',
    '발견한 유물, Curios 슬롯, 수리 재료',
    ['유물 설명과 장착 슬롯을 확인합니다.', 'Curios 화면에서 올바른 슬롯에 장착합니다.', '공장 작업용과 탐험용 세트를 구분합니다.', '중복 효과와 내구도를 확인합니다.'],
    '장착 슬롯 충돌과 효과 발동 조건을 확인하세요.'
  )
})

const GUIDE_GROUPS = [
  'Create: 철판, 안산암, 황동, 증기발전기, 디젤발전기, 전기발전, 신시대, 철도',
  'Create 확장: 와이너리, 카페, 마법부여, 광맥채굴, 광부클론, 이동식패키지, 파워로더, 드래곤',
  'AE2: ae2저장, ae2자동조합, 고급ae, 메가셀, 무선ae',
  '자원/생활: 벌, 몬스터자원, 농사, 낚시, 배낭, 고급저장, 간단저장, 화로',
  '건축/기타: 가구, 건축, 조명, 상점, 길찾기, 낚시휴식, 유물'
]

function showGuideList(source) {
  const player = playerFrom(source)
  if (!player) return 0
  tell(player, '━━━━━━━━ 공장도우미 목록 ━━━━━━━━', 'gold')
  GUIDE_GROUPS.forEach(line => tell(player, line, 'yellow'))
  tell(player, '사용법: /공장도우미 <항목>', 'green')
  return 1
}

const DESIGN_RULES = {
  '철판': {
    unlock: 13, unit: '개/시간', machineRate: 96, machine: '기계식 프레스',
    power: '물레방아 1개 또는 동급 회전원',
    flow: '입력 상자 → 황동 깔때기 → 벨트 → 프레스 → 출력 상자',
    parts: count => `프레스 ${count}, 5칸 벨트 ${count}, 황동 깔때기 ${count * 2}, 재고 감지기 1`,
    bottleneck: '철 주괴 공급과 출력 상자 포화'
  },
  '안산암': {
    unlock: 15, unit: '개/시간', machineRate: 64, machine: '기계식 믹서+분지',
    power: '중형 물레방아 또는 증기 동력',
    flow: '안산암/철 재료 상자 → 필터 깔때기 → 분지+믹서 → 출력',
    parts: count => `믹서 ${count}, 분지 ${count}, 가열원 ${count}, 입력 필터 ${count * 2}`,
    bottleneck: '두 입력 재료의 비율과 가열 조건'
  },
  '황동': {
    unlock: 24, unit: '개/시간', machineRate: 48, machine: '가열 믹서',
    power: '증기 발전기 권장',
    flow: '구리/아연 상자 → 필터 투입 → 가열 분지 → 황동 출력',
    parts: count => `믹서 ${count}, 분지 ${count}, 블레이즈 버너 ${count}, 유량/재고 감지 1`,
    bottleneck: '블레이즈 버너 연료와 아연 공급'
  },
  '조약돌': {
    unlock: 7, unit: '개/시간', machineRate: 320, machine: '기계식 드릴',
    power: '물레방아 1개',
    flow: '물+용암 생성 칸 → 드릴 → 벨트 → 금고',
    parts: count => `드릴 ${count}, 생성 칸 ${count}, 수집 벨트 1줄, 금고 1`,
    bottleneck: '출력 저장량과 드롭 수집'
  },
  '나무': {
    unlock: 16, unit: '원목/시간', machineRate: 280, machine: '회전식 나무 농장',
    power: '물레방아 또는 풍차',
    flow: '원형 농장 → 회전 톱 → 이동식 저장소 → 저장 인터페이스',
    parts: count => `독립 농장 ${count}, 베어링 ${count}, 톱 ${count * 4}, 이동식 저장소 ${count}`,
    bottleneck: '묘목 재식재와 저장 인터페이스 배출'
  },
  '광석': {
    unlock: 23, unit: '스택/시간', machineRate: 18, machine: '분쇄·세척 라인',
    power: '중형 증기 동력 권장',
    flow: '원광 입력 → 분쇄 휠 → 팬 세척 → 필터 분류 → 저장',
    parts: count => `분쇄 휠 ${count * 2}, 세척 팬 ${count}, 벨트 라인 ${count}, 필터 출력 4종+`,
    bottleneck: '분쇄 휠 처리 속도와 부산물 분류'
  },
  '음식': {
    unlock: 35, unit: '세트/시간', machineRate: 48, machine: '혼합·조리 라인',
    power: '소형 물레방아',
    flow: '재료별 저장소 → 필터 투입 → 혼합/가열 → 용기 회수 → 음식 저장',
    parts: count => `믹서/조리 모듈 ${count}, 재료 입력 3종+, 용기 회수 라인 1`,
    bottleneck: '작물 생산량과 빈 그릇/병 회수'
  },
  'ae2프로세서': {
    unlock: 48, unit: '개/시간', machineRate: 80, machine: '각인기 묶음',
    power: '안정적인 FE 전력망',
    flow: '전용 프레스 각인기 → 인쇄 부품 버퍼 → 최종 조립 각인기 → ME 회수',
    parts: count => `전용 각인기 ${count * 4}, 최종 조립 각인기 ${count}, 패턴 공급기 ${count * 5}`,
    bottleneck: '인쇄 실리콘과 중간 부품 버퍼'
  },
  '물류센터': {
    unlock: 44, unit: '입출력 라인', machineRate: 8, machine: 'AE2 중앙 물류 허브',
    power: 'AE2 전력+채널 여유 25% 권장',
    flow: '공장 출력 버퍼 → 가져오기 버스 → ME망 → 내보내기 버스 → 공장 입력 버퍼',
    parts: count => `입력 버퍼 ${count}, 출력 버퍼 ${count}, 가져오기 버스 ${count}, 내보내기 버스 ${count}, 비상 상자 1`,
    bottleneck: 'AE2 채널, 순환 공급, 단일 셀 타입 포화'
  },
  '증기발전기': {
    unlock: 32, unit: '동력 모듈', machineRate: 2, machine: '보일러+증기 기관',
    power: '자체 발전',
    flow: '무한 물 공급 → 보일러 탱크 → 가열 → 증기 기관 → 주 동력축',
    parts: count => `2×2 보일러 ${count}, 증기 기관 ${count * 2}, 물 공급 ${count}, 안전 클러치 ${count}`,
    bottleneck: '물 공급 중단과 과도한 응력 사용'
  }
}

function firstIncompleteIndex(player) {
  const data = TeamData.get(player)
  for (var incompleteQuestIndex = 0; incompleteQuestIndex < QUEST_IDS.length; incompleteQuestIndex++) {
    var incompleteQuest = questAt(incompleteQuestIndex)
    if (incompleteQuest && !data.isCompleted(incompleteQuest)) {
      return incompleteQuestIndex
    }
  }
  return QUEST_IDS.length
}

function showDesignList(source) {
  const player = playerFrom(source)
  if (!player) return 0
  tell(player, '━━━━━━━━ 무료 공장설계 ━━━━━━━━', 'gold')
  tell(player, '철판, 안산암, 황동, 조약돌, 나무, 광석, 음식, ae2프로세서, 물류센터, 증기발전기', 'yellow')
  tell(player, '사용법: /공장설계 <항목> <목표량>', 'green')
  tell(player, '예: /공장설계 철판 128 · /공장설계 물류센터 12', 'gray')
  return 1
}

function showDesign(source, key, target) {
  const player = playerFrom(source)
  if (!player) return 0
  const rule = DESIGN_RULES[key]
  const machines = Math.max(1, Math.ceil(target / rule.machineRate))
  const capacity = machines * rule.machineRate
  const safeCapacity = Math.floor(capacity * 0.75)
  const progress = firstIncompleteIndex(player)

  tell(player, `━━━━━━━━ ${key} 공장 권장 설계 ━━━━━━━━`, 'gold')
  tell(player, `목표: ${target} ${rule.unit}`, 'yellow')
  tell(player, `권장 규모: ${rule.machine} ${machines}모듈`, 'aqua')
  tell(player, `이론 처리량: ${capacity} · 안정 운전 권장량: ${safeCapacity} ${rule.unit}`, 'white')
  tell(player, `동력: ${rule.power}`, 'white')
  tell(player, `흐름: ${rule.flow}`, 'green')
  tell(player, `장치: ${rule.parts(machines)}`, 'white')
  tell(player, `병목: ${rule.bottleneck}`, 'red')
  tell(player, '안전장치: 출력 버퍼가 차면 재고 감지기→레드스톤 링크→클러치로 정지', 'light_purple')
  tell(player, '확장 원칙: 한 줄을 복제하기 전에 입력·출력 버퍼가 비는지 먼저 확인', 'gray')

  if (progress <= rule.unlock) {
    const needed = questAt(rule.unlock)
    const neededTitle = needed ? needed.getTitle().getString() : `퀘스트 ${rule.unlock + 1}`
    tell(player, `현재 단계에서는 이 설계가 이릅니다. 먼저 ${neededTitle}까지 진행하세요.`, 'red')
  } else {
    tell(player, '현재 퀘스트 진행 단계에서 제작 가능한 설계입니다.', 'green')
  }
  return 1
}

const STARTER_TIERS = [
  { material: 'iron', name: '철', weight: 55, maxLevel: 2 },
  { material: 'diamond', name: '다이아몬드', weight: 35, maxLevel: 3 },
  { material: 'netherite', name: '네더라이트', weight: 10, maxLevel: 4 }
]

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function weightedTier() {
  const roll = randomInt(1, 100)
  let total = 0
  for (var tier of STARTER_TIERS) {
    total += tier.weight
    if (roll <= total) return tier
  }
  return STARTER_TIERS[0]
}

function enchantmentsFor(kind, tier) {
  const levels = {}
  const durability = randomInt(1, Math.min(3, tier.maxLevel))
  levels['minecraft:unbreaking'] = durability

  if (kind === 'pickaxe') {
    levels['minecraft:efficiency'] = randomInt(1, Math.min(5, tier.maxLevel + 1))
    const special = randomInt(1, 100)
    if (special <= 35) levels['minecraft:fortune'] = randomInt(1, Math.min(3, tier.maxLevel))
    else if (special <= 50) levels['minecraft:silk_touch'] = 1
  } else if (kind === 'axe') {
    levels['minecraft:efficiency'] = randomInt(1, Math.min(5, tier.maxLevel + 1))
    const special = randomInt(1, 100)
    if (special <= 25) levels['minecraft:fortune'] = randomInt(1, Math.min(3, tier.maxLevel))
    else if (special <= 38) levels['minecraft:silk_touch'] = 1
    if (randomInt(1, 100) <= 30) levels['minecraft:sharpness'] = randomInt(1, Math.min(5, tier.maxLevel))
  } else {
    const damageRoll = randomInt(1, 100)
    if (damageRoll <= 65) levels['minecraft:sharpness'] = randomInt(1, Math.min(5, tier.maxLevel + 1))
    else if (damageRoll <= 85) levels['minecraft:smite'] = randomInt(1, Math.min(5, tier.maxLevel + 1))
    else levels['minecraft:bane_of_arthropods'] = randomInt(1, Math.min(5, tier.maxLevel + 1))
    if (randomInt(1, 100) <= 55) levels['minecraft:looting'] = randomInt(1, Math.min(3, tier.maxLevel))
    if (randomInt(1, 100) <= 35) levels['minecraft:sweeping_edge'] = randomInt(1, Math.min(3, tier.maxLevel))
  }

  // A rare bonus that does not invalidate the early durability game every time.
  if (randomInt(1, 100) <= 8) levels['minecraft:mending'] = 1
  return levels
}

function componentString(levels) {
  const entries = Object.keys(levels).map(id => `"${id}":${levels[id]}`).join(',')
  return `[minecraft:enchantments={levels:{${entries}}}]`
}

function enchantSummary(levels) {
  const korean = {
    'minecraft:unbreaking': '내구성',
    'minecraft:efficiency': '효율',
    'minecraft:fortune': '행운',
    'minecraft:silk_touch': '섬세한 손길',
    'minecraft:sharpness': '날카로움',
    'minecraft:smite': '강타',
    'minecraft:bane_of_arthropods': '살충',
    'minecraft:looting': '약탈',
    'minecraft:sweeping_edge': '휩쓸기',
    'minecraft:mending': '수선'
  }
  return Object.keys(levels).map(id => `${korean[id] || id} ${levels[id]}`).join(', ')
}

function giveStarterTools(source) {
  const player = playerFrom(source)
  if (!player) return 0
  const data = player.persistentData
  if (data.getBoolean('create_academy_starter_tools_claimed')) {
    tell(player, '초반 랜덤 도구는 계정당 한 번만 받을 수 있습니다.', 'red')
    return 0
  }

  const tools = [
    { kind: 'pickaxe', korean: '곡괭이' },
    { kind: 'axe', korean: '도끼' },
    { kind: 'sword', korean: '검' }
  ]
  const results = []

  try {
    for (var tool of tools) {
      var starterTier = weightedTier()
      var starterLevels = enchantmentsFor(tool.kind, starterTier)
      var starterItemId = `minecraft:${starterTier.material}_${tool.kind}`
      var starterStack = Item.of(
        `${starterItemId}${componentString(starterLevels)}`
      )
      if (starterStack.isEmpty()) {
        throw new Error(`아이템 생성 실패: ${starterItemId}`)
      }
      player.give(starterStack)
      results.push(
        `${starterTier.name} ${tool.korean}: ${enchantSummary(starterLevels)}`
      )
    }
  } catch (error) {
    console.error(`[초반도구] ${error}`)
    tell(player, `도구 지급 중 오류: ${error}`, 'red')
    return 0
  }

  data.putBoolean('create_academy_starter_tools_claimed', true)
  tell(player, '━━━━━━━━ 초반 랜덤 도구 지급 완료 ━━━━━━━━', 'gold')
  results.forEach(line => tell(player, line, 'aqua'))
  tell(player, '이 명령어는 한 번만 사용할 수 있습니다.', 'yellow')
  return 1
}

function showFactory(source, key) {
  const player = playerFrom(source)
  if (!player) return 0
  const factory = FACTORIES[key]
  tell(player, `━━━━━━━━ ${factory.title} ━━━━━━━━`, 'gold')
  tell(player, `준비물: ${factory.materials}`, 'yellow')
  factory.steps.forEach((step, i) => tell(player, `${i + 1}. ${step}`, 'white'))
  tell(player, `점검: ${factory.check}`, 'red')
  tell(player, '장치를 든 상태에서 W를 길게 눌러 Ponder도 확인하세요.', 'aqua')
  return 1
}

ServerEvents.commandRegistry(event => {
  const { commands: Commands } = event

  let today = Commands.literal('오늘할일')
    .executes(context => showToday(context.source, 120))
    .then(Commands.literal('30분').executes(context => showToday(context.source, 30)))
    .then(Commands.literal('1시간').executes(context => showToday(context.source, 60)))
    .then(Commands.literal('2시간').executes(context => showToday(context.source, 120)))
    .then(Commands.literal('3시간').executes(context => showToday(context.source, 180)))
  event.register(today)

  let factory = Commands.literal('공장도우미')
    .executes(context => showGuideList(context.source))
    .then(Commands.literal('목록').executes(context => showGuideList(context.source)))
  Object.keys(FACTORIES).forEach(key => {
    factory = factory.then(Commands.literal(key).executes(context => showFactory(context.source, key)))
  })
  event.register(factory)

  let designer = Commands.literal('공장설계')
    .executes(context => showDesignList(context.source))
    .then(Commands.literal('목록').executes(context => showDesignList(context.source)))
  Object.keys(DESIGN_RULES).forEach(key => {
    designer = designer.then(
      Commands.literal(key)
        .executes(context => showDesign(context.source, key, DESIGN_RULES[key].machineRate))
        .then(
          Commands.argument('목표량', IntegerArgumentType.integer(1, 4096))
            .executes(context => showDesign(context.source, key, IntegerArgumentType.getInteger(context, '목표량')))
        )
    )
  })
  event.register(designer)

  event.register(
    Commands.literal('초반도구')
      .executes(context => giveStarterTools(context.source))
  )
})

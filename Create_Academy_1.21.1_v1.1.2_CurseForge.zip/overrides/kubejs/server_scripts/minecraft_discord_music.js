// Minecraft -> Discord music bridge.
// /discordmusic play <YouTube URL>
// /discordmusic stop
// Korean aliases:
// /디스코드음악 <YouTube URL>
// /디스코드음악정지
(() => {
  var McMusicStringArgument = Java.loadClass(
    'com.mojang.brigadier.arguments.StringArgumentType'
  )

  function mcMusicValidUrl(url) {
    return /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(url)
  }

  ServerEvents.commandRegistry(event => {
    var McMusicCommands = event.commands

    function sendPlaySignal(context, argumentName) {
      var url = String(
        McMusicStringArgument.getString(context, argumentName)
      ).trim()

      if (!mcMusicValidUrl(url)) {
        context.source.sendFailure(
          Text.of('올바른 YouTube 링크를 입력해주세요.')
        )
        return 0
      }

      console.info(`[MC_DISCORD_MUSIC_PLAY] ${url}`)
      context.source.sendSuccess(
        Text.of('Discord 음악 봇에 재생을 요청했습니다.').green(),
        false
      )
      return 1
    }

    function sendStopSignal(context) {
      console.info('[MC_DISCORD_MUSIC_STOP]')
      context.source.sendSuccess(
        Text.of('Discord 음악 정지를 요청했습니다.').yellow(),
        false
      )
      return 1
    }

    event.register(
      McMusicCommands.literal('discordmusic')
        .then(
          McMusicCommands.literal('play')
            .then(
              McMusicCommands.argument(
                'youtube_url',
                McMusicStringArgument.greedyString()
              ).executes(context => sendPlaySignal(context, 'youtube_url'))
            )
        )
        .then(
          McMusicCommands.literal('stop')
            .executes(context => sendStopSignal(context))
        )
    )

    event.register(
      McMusicCommands.literal('디스코드음악')
        .then(
          McMusicCommands.argument(
            'youtube_url_ko',
            McMusicStringArgument.greedyString()
          ).executes(context => sendPlaySignal(context, 'youtube_url_ko'))
        )
    )

    event.register(
      McMusicCommands.literal('디스코드음악정지')
        .executes(context => sendStopSignal(context))
    )
  })
})()

// Stationary miner clone for Create Academy
// /광부클론 소환, /광부클론 충전, /광부클론 상태, /광부클론 회수

function clonePlayer(source) {
  try { return source.getPlayerOrException() } catch (e) { return null }
}

function cloneTell(player, text, color) {
  player.tell(Text.of(text).color(color || 'white'))
}

ServerEvents.commandRegistry(event => {
  const { commands: Commands } = event

  event.register(
    Commands.literal('광부클론')
      .executes(context => {
        const player = clonePlayer(context.source)
        cloneTell(player, '사용법: /광부클론 소환 | 충전 | 상태 | 회수', 'yellow')
        return 1
      })
      .then(
        Commands.literal('소환').executes(context => {
          const source = context.source
          const player = clonePlayer(source)
          if (!player) return 0
          if (source.server.runCommandSilent('execute if entity @e[tag=create_academy_miner_clone,limit=1]') > 0) {
            cloneTell(player, '이미 작동 중인 광부 클론이 있습니다.', 'red')
            return 0
          }

          const name = player.getGameProfile().getName()
          const nbt = `{Tags:["create_academy_miner_clone"],CustomName:'{"text":"${name}의 광부 클론","color":"aqua"}',CustomNameVisible:1b,NoGravity:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1b,ArmorItems:[{id:"minecraft:iron_boots",count:1},{id:"minecraft:iron_leggings",count:1},{id:"minecraft:iron_chestplate",count:1},{id:"minecraft:iron_helmet",count:1}],HandItems:[{id:"minecraft:diamond_pickaxe",count:1},{}],Pose:{RightArm:[315f,0f,10f],LeftArm:[335f,0f,350f]}}`
          source.server.runCommandSilent(`execute at ${name} run summon minecraft:armor_stand ~ ~ ~ ${nbt}`)
          source.server.runCommandSilent('scoreboard players set @e[tag=create_academy_miner_clone,limit=1,sort=nearest] clone_energy 64')
          source.server.runCommandSilent('scoreboard players set @e[tag=create_academy_miner_clone,limit=1,sort=nearest] clone_cd 0')
          source.server.runCommandSilent('scoreboard players set @e[tag=create_academy_miner_clone,limit=1,sort=nearest] clone_mined 0')
          cloneTell(player, '광부 클론을 소환했습니다. 주변 광석을 2초마다 하나씩 채굴합니다.', 'aqua')
          cloneTell(player, '범위: 가로 11×11, 높이 7 · 초기 에너지: 64', 'gray')
          return 1
        })
      )
      .then(
        Commands.literal('충전').executes(context => {
          const source = context.source
          const player = clonePlayer(source)
          if (!player) return 0
          if (source.server.runCommandSilent('execute if entity @e[tag=create_academy_miner_clone,limit=1]') <= 0) {
            cloneTell(player, '먼저 광부 클론을 소환하세요.', 'red')
            return 0
          }
          const name = player.getGameProfile().getName()
          const coalCount = source.server.runCommandSilent(`clear ${name} minecraft:coal 0`)
          if (coalCount < 8) {
            cloneTell(player, `충전에는 석탄 8개가 필요합니다. 현재 ${coalCount}개입니다.`, 'red')
            return 0
          }
          source.server.runCommandSilent(`clear ${name} minecraft:coal 8`)
          source.server.runCommandSilent('scoreboard players add @e[tag=create_academy_miner_clone,limit=1] clone_energy 64')
          cloneTell(player, '석탄 8개를 사용해 채굴 에너지 64를 충전했습니다.', 'green')
          return 1
        })
      )
      .then(
        Commands.literal('상태').executes(context => {
          const source = context.source
          const player = clonePlayer(source)
          if (!player) return 0
          if (source.server.runCommandSilent('execute if entity @e[tag=create_academy_miner_clone,limit=1]') <= 0) {
            cloneTell(player, '현재 소환된 광부 클론이 없습니다.', 'gray')
            return 0
          }
          source.server.runCommandSilent(`tellraw ${player.getGameProfile().getName()} [{"text":"광부 클론 남은 에너지: ","color":"aqua"},{"score":{"name":"@e[tag=create_academy_miner_clone,limit=1]","objective":"clone_energy"},"color":"yellow"}]`)
          return 1
        })
      )
      .then(
        Commands.literal('회수').executes(context => {
          const source = context.source
          const player = clonePlayer(source)
          if (!player) return 0
          const result = source.server.runCommandSilent('kill @e[tag=create_academy_miner_clone]')
          cloneTell(player, result > 0 ? '광부 클론을 회수했습니다.' : '회수할 광부 클론이 없습니다.', result > 0 ? 'green' : 'gray')
          return result > 0 ? 1 : 0
        })
      )
  )
})

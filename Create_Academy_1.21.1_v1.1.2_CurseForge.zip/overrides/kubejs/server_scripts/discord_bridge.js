// KubeJS writes Minecraft events to its server log.
// The Discord bot watches that log and sends the notifications.
(() => {
  const DISCORD_HOST_NAME = 'L_piyo'
  const PUBLIC_COMMANDS = [
    '오늘할일', '공장도우미', '공장설계', '초반도구',
    '광부클론', '디스코드음악', '디스코드음악정지',
    'discordmusic', 'discordtest', 'servermusic',
    'help', 'list', 'msg', 'tell', 'w', 'whisper',
    'trigger', 'teammsg', 'tm'
  ]

  function discordLog(message) {
    console.info(`[KUBEJS-DISCORD] ${message}`)
  }

  function safeCommandForDiscord(input) {
    const raw = String(input).replace(/^\/+/, '').trim()
    const commandName = raw.split(/\s+/)[0].toLowerCase()
    const privateCommands = [
      'login', 'register', 'changepassword', 'password',
      'msg', 'tell', 'w', 'whisper', 'me',
      'webhook', 'token'
    ]

    if (privateCommands.includes(commandName)) {
      return `/${commandName} <내용 숨김>`
    }

    return `/${raw}`.slice(0, 500)
  }

  function firstCommandName(input) {
    return String(input)
      .replace(/^\/+/, '')
      .trim()
      .split(/\s+/)[0]
      .toLowerCase()
  }

  ServerEvents.loaded(event => {
    discordLog('SERVER_LOADED')
  })

  ServerEvents.unloaded(event => {
    discordLog('SERVER_UNLOADED')
  })

  PlayerEvents.loggedIn(event => {
    discordLog(`LOGIN: ${event.player.username}`)
  })

  PlayerEvents.loggedOut(event => {
    discordLog(`LOGOUT: ${event.player.username}`)
  })

  function recordPlayerCommand(event) {
    var shouldBlockCommandForDiscord = false
    var blockedCommandPlayerForDiscord = null

    try {
      var commandSourceForDiscord = event.parseResults.context.source
      var commandPlayerForDiscord = commandSourceForDiscord.player
      if (!commandPlayerForDiscord) return

      var commandPlayerNameForDiscord = String(commandPlayerForDiscord.username)
      var safePlayerCommandForDiscord = safeCommandForDiscord(event.input)

      if (
        commandPlayerNameForDiscord !== DISCORD_HOST_NAME &&
        !PUBLIC_COMMANDS.includes(firstCommandName(event.input))
      ) {
        discordLog(
          `BLOCKED_COMMAND: ${commandPlayerNameForDiscord}: ${safePlayerCommandForDiscord}`
        )
        shouldBlockCommandForDiscord = true
        blockedCommandPlayerForDiscord = commandPlayerForDiscord
      } else {
        discordLog(
          `PLAYER_COMMAND: ${commandPlayerNameForDiscord}: ${safePlayerCommandForDiscord}`
        )
      }
    } catch (error) {
      console.error(`[KUBEJS-DISCORD] 명령어 감지 실패: ${error}`)
    }

    if (shouldBlockCommandForDiscord) {
      blockedCommandPlayerForDiscord.tell(
        Text.of('이 명령어는 호스트만 사용할 수 있습니다.').red()
      )
      return event.cancel()
    }
  }

  ServerEvents.command(recordPlayerCommand)

  ServerEvents.commandRegistry(event => {
    const { commands: Commands } = event
    const StringArgumentType = Java.loadClass(
      'com.mojang.brigadier.arguments.StringArgumentType'
    )

    event.register(
      Commands.literal('discordtest')
        .requires(source => source.hasPermission(2))
        .then(
          Commands.argument('message', StringArgumentType.greedyString())
            .executes(context => {
              context.getSource().sendSuccess(
                Text.of('디스코드 테스트 명령이 로그에 기록되었습니다.').green(),
                false
              )
              return 1
            })
        )
    )
  })
})()

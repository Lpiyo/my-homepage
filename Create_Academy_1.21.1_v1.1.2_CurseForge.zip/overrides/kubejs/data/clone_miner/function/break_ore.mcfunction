loot spawn ~ ~ ~ mine ~ ~ ~ minecraft:diamond_pickaxe
setblock ~ ~ ~ air
scoreboard players remove @s clone_energy 1
scoreboard players set @s clone_mined 1
particle minecraft:poof ~0.5 ~0.5 ~0.5 0.2 0.2 0.2 0.01 8 normal
playsound minecraft:block.stone.break block @a[distance=..24] ~ ~ ~ 0.7 1.1

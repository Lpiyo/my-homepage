scoreboard players add @e[tag=create_academy_miner_clone] clone_cd 1
scoreboard players set @e[tag=create_academy_miner_clone,scores={clone_cd=40..}] clone_cd 0
scoreboard players set @e[tag=create_academy_miner_clone,scores={clone_cd=0,clone_energy=1..}] clone_mined 0
execute as @e[tag=create_academy_miner_clone,scores={clone_cd=0,clone_energy=1..}] at @s run function clone_miner:scan

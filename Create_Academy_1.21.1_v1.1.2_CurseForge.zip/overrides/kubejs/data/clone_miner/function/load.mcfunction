scoreboard objectives add clone_cd dummy
scoreboard objectives add clone_energy dummy
scoreboard objectives add clone_mined dummy

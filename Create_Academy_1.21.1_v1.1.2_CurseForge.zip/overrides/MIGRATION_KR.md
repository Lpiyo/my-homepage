# 1.20.1 → 1.21.1 마이그레이션

## 핵심 변경

- Forge 47.4.20 → NeoForge 21.1.233
- Create 6.0.8 → Create 6.0.10
- AE2 15.4.10 → AE2 19.2.17
- FTB Quests 2001 → FTB Quests 2101
- Oculus → Iris
- 기존 123개 모드 → 검증된 의존성을 포함한 69개 모드

## 유지·업데이트한 주요 기능

- Create, Crafts & Additions, Steam 'n' Rails, Copycats+, Create Deco
- Enchantment Industry, Diesel Generators, New Age, Connected
- Central Kitchen, Mobile Packages, Power Loader, Ultimate Factory
- Create Cafe, Winery, Framed, Ore Excavation
- AE2, AE2 Wireless Terminals, MEGA Cells, Advanced AE
- Productive Bees, Farmer's Delight, Aquaculture 계열
- Sophisticated Backpacks/Storage, Tom's Storage
- Chipped, Handcrafted, Supplementaries, Macaw 건축 모드
- HNN, Lightman's Currency, JEI, Jade, Xaero's Minimap

## 제거하거나 대체한 항목

- `Oculus` → `Iris`
- `Create Mob Spawners`, `AgeingSpawners`, `SpawnBalanceUtility` → 서버 부하가 적은 `Hostile Neural Networks`
- `Iron Chests` → `Sophisticated Storage`
- `Inventory Management`, `Inventory Tweaks` → `Inventory Essentials`
- `Create Kart` → 기본 Create 철도와 안정판 Steam 'n' Rails
- `Create Hypertube` → 1.21.1 안정판이 없어 제외
- `Apotheosis` 계열 → 1.21.1 팩에서 제외하고 Create Enchantment Industry로 마법 자동화 역할 축소
- `Ad Astra` → 이번 안정 구성에서 제외
- `KryptonReforged`, `Connectivity`, `XL Packets`, `SmoothChunk`, `ChunkSending` → NeoForge 1.21.1에서 중복 네트워크 패치를 줄이기 위해 제외
- `AllTheLeaks`, `Neruina`, `Mobtimizations` → ModernFix, FerriteCore, Embeddium, Entity Culling 중심으로 단순화

## 월드 이전 주의

기존 월드에는 제거된 모드의 블록과 아이템이 포함되어 있습니다. 그대로 열면 해당 블록이 사라지거나 월드가 손상될 수 있습니다.

권장 순서:

1. 기존 월드를 ZIP으로 백업합니다.
2. 1.20.1 월드에서 제거 대상 모드 블록을 철거합니다.
3. 중요한 아이템은 바닐라 상자와 바닐라 아이템 형태로 정리합니다.
4. 가능하면 1.21.1에서는 새 월드를 시작합니다.

Create와 AE2는 대형 데이터 구조를 저장하므로 기존 공장 월드의 직접 업그레이드는 보장하지 않습니다.
